import { createContext, useContext, useState, useMemo } from "react";

// Create the context object. Components import useCart() instead of this directly.
const CartContext = createContext(null);

export function CartProvider({ children }) {
  // cartItems is an array of { id, name, price, imgName, imageId, quantity }
  const [cartItems, setCartItems] = useState([]);

  // Add an item to the cart. If it already exists, just bump the quantity.
  function addToCart(item) {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.cartKey === item.cartKey);
      if (existing) {
        return prev.map((i) =>
          i.cartKey === item.cartKey ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  }

  // Increase quantity of an existing cart item by 1.
  function increaseQuantity(cartKey) {
    setCartItems((prev) =>
      prev.map((i) =>
        i.cartKey === cartKey ? { ...i, quantity: i.quantity + 1 } : i
      )
    );
  }

  // Decrease quantity of an existing cart item by 1.
  // If quantity hits 0, the item is removed from the cart entirely.
  function decreaseQuantity(cartKey) {
    setCartItems((prev) =>
      prev
        .map((i) =>
          i.cartKey === cartKey ? { ...i, quantity: i.quantity - 1 } : i
        )
        .filter((i) => i.quantity > 0)
    );
  }

  // Remove an item from the cart completely, regardless of quantity.
  function removeFromCart(cartKey) {
    setCartItems((prev) => prev.filter((i) => i.cartKey !== cartKey));
  }

  // Empty the whole cart (used after "checkout").
  function clearCart() {
    setCartItems([]);
  }

  // Total number of individual items in the cart (sum of quantities),
  // used for the badge in the Navbar.
  const cartCount = useMemo(
    () => cartItems.reduce((sum, i) => sum + i.quantity, 0),
    [cartItems]
  );

  // Total price in rupees (price is already stored in rupees, not paise).
  const cartTotal = useMemo(
    () => cartItems.reduce((sum, i) => sum + i.price * i.quantity, 0),
    [cartItems]
  );

  const value = {
    cartItems,
    addToCart,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
    clearCart,
    cartCount,
    cartTotal,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

// Custom hook so components can do `const { cartItems, addToCart } = useCart()`
// instead of importing useContext + CartContext everywhere.
export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error("useCart must be used inside a <CartProvider>");
  }
  return ctx;
}
