import { getMenuItemImage, formatPrice } from "../utils/dataHelpers";
import { useCart } from "../context/CartContext";
import "../styles/MenuItemCard.css";

function MenuItemCard({ item, categoryTitle }) {
  const { addToCart } = useCart();

  const {
    name,
    description,
    defaultPrice,
    rating,
    ratingCount,
    isVeg,
    inStock,
  } = item;

  // A unique key for cart purposes -- since some ids repeat across categories,
  // we combine category + name + id to be safe.
  const cartKey = `${categoryTitle}-${name}-${item.id}`;
  const outOfStock = inStock === 0;

  function handleAdd() {
    if (outOfStock) return;
    addToCart({
      cartKey,
      id: item.id,
      name,
      price: defaultPrice / 100, // store price in rupees, not paise
      image: getMenuItemImage(item),
    });
  }

  return (
    <div className={`menu-item-card ${outOfStock ? "out-of-stock" : ""}`}>
      <div className="menu-item-info">
        <div className="menu-item-title-row">
          {isVeg === 1 && <span className="veg-dot" title="Veg" />}
          <h4 className="menu-item-name">{name}</h4>
        </div>

        {defaultPrice != null && (
          <p className="menu-item-price">{formatPrice(defaultPrice)}</p>
        )}

        {rating && (
          <p className="menu-item-rating">
            ★ {rating} {ratingCount ? `(${ratingCount})` : ""}
          </p>
        )}

        {description && <p className="menu-item-description">{description}</p>}

        <button
          className="menu-item-add-btn"
          onClick={handleAdd}
          disabled={outOfStock}
        >
          {outOfStock ? "Out of stock" : "Add to Cart"}
        </button>
      </div>

      <div className="menu-item-image-wrap">
        <img
          src={getMenuItemImage(item)}
          alt={name}
          className="menu-item-image"
          onError={(e) => {
            e.target.src = "/images/food.jpeg";
          }}
        />
      </div>
    </div>
  );
}

export default MenuItemCard;
