import { useCart } from "../context/CartContext";
import "../styles/CartItemRow.css";

function CartItemRow({ item }) {
  const { increaseQuantity, decreaseQuantity, removeFromCart } = useCart();

  return (
    <div className="cart-item-row">
      <img
        src={item.image}
        alt={item.name}
        className="cart-item-image"
        onError={(e) => {
          e.target.src = "/images/food.jpeg";
        }}
      />

      <div className="cart-item-details">
        <h4>{item.name}</h4>
        <p className="cart-item-unit-price">₹{item.price.toFixed(2)} each</p>
      </div>

      <div className="cart-item-quantity-controls">
        <button onClick={() => decreaseQuantity(item.cartKey)} aria-label="Decrease quantity">
          −
        </button>
        <span>{item.quantity}</span>
        <button onClick={() => increaseQuantity(item.cartKey)} aria-label="Increase quantity">
          +
        </button>
      </div>

      <p className="cart-item-subtotal">
        ₹{(item.price * item.quantity).toFixed(2)}
      </p>

      <button
        className="cart-item-remove"
        onClick={() => removeFromCart(item.cartKey)}
        aria-label="Remove item"
      >
        Remove
      </button>
    </div>
  );
}

export default CartItemRow;
