import "../styles/SearchBar.css";

function SearchBar({ value, onChange }) {
  return (
    <div className="search-bar">
      <input
        type="text"
        placeholder="Search restaurants, cuisines, or area..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="search-bar-input"
      />
      {value && (
        <button
          className="search-bar-clear"
          onClick={() => onChange("")}
          aria-label="Clear search"
        >
          ✕
        </button>
      )}
    </div>
  );
}

export default SearchBar;
