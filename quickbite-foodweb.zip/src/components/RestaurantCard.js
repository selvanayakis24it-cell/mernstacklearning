import { Link } from "react-router-dom";
import { getRestaurantImage, formatCuisines } from "../utils/dataHelpers";
import "../styles/RestaurantCard.css";

function RestaurantCard({ restaurant }) {
  const {
    id,
    name,
    cloudinaryImageId,
    cuisines,
    avgRatingString,
    areaName,
    locality,
    costForTwo,
    veg,
  } = restaurant;

  return (
    <Link to={`/restaurant/${id}`} className="restaurant-card">
      <div className="restaurant-card-image-wrap">
        <img
          src={getRestaurantImage(cloudinaryImageId)}
          alt={name}
          className="restaurant-card-image"
          onError={(e) => {
            e.target.src = "/images/food.jpeg";
          }}
        />
        {veg === true && <span className="veg-badge" title="Pure Veg" />}
        {avgRatingString && (
          <span className="restaurant-card-rating">
            ★ {avgRatingString}
          </span>
        )}
      </div>

      <div className="restaurant-card-body">
        <h3 className="restaurant-card-name">{name}</h3>
        <p className="restaurant-card-cuisines">{formatCuisines(cuisines)}</p>
        <div className="restaurant-card-meta">
          <span>{areaName || locality}</span>
          {costForTwo && <span>{costForTwo}</span>}
        </div>
      </div>
    </Link>
  );
}

export default RestaurantCard;
