// Small helper functions shared across the app.
// These exist because the real Restaurant.json / menu.json data is a bit messy:
// some fields are missing on some items, prices are stored in paise, and a few
// menu item "id" values are duplicated. These helpers paper over all of that
// so components don't have to worry about it.

// Convert price from paise (e.g. 12500) to a formatted rupee string (e.g. "₹125").
export function formatPrice(paise) {
  if (typeof paise !== "number") return "₹--";
  const rupees = paise / 100;
  // Show no decimals if it's a whole number, otherwise show 2 decimals.
  return `₹${rupees % 1 === 0 ? rupees : rupees.toFixed(2)}`;
}

// Build the correct image src for a restaurant logo.
// cloudinaryImageId in Restaurant.json has NO file extension, but the actual
// files in public/images/ are .avif, so we add it here.
export function getRestaurantImage(cloudinaryImageId) {
  if (!cloudinaryImageId) return "/images/food.jpeg";
  return `/images/${cloudinaryImageId}.avif`;
}

// Build the correct image src for a menu item.
// menu.json items sometimes have "imgName" (already includes its extension,
// e.g. "pizza.jpeg") and sometimes only "imageId" (no extension, .avif file),
// and sometimes neither. Fall back to a generic placeholder in that case.
export function getMenuItemImage(item) {
  if (item.imgName) return `/images/${item.imgName}`;
  if (item.imageId) return `/images/${item.imageId}.avif`;
  return "/images/food.jpeg";
}

// A handful of menu items in menu.json share the same "id" value, which breaks
// React's key-uniqueness requirement and can cause duplicate items to render
// incorrectly. This builds a guaranteed-unique key from category + name + index.
export function buildMenuItemKey(categoryTitle, item, index) {
  return `${categoryTitle}-${item.name}-${item.id}-${index}`;
}

// Join the cuisines array into a comma separated string, truncated so long
// cuisine lists don't break the restaurant card layout.
export function formatCuisines(cuisines, maxLength = 40) {
  if (!Array.isArray(cuisines) || cuisines.length === 0) return "Multi-cuisine";
  const joined = cuisines.join(", ");
  if (joined.length <= maxLength) return joined;
  return joined.slice(0, maxLength).trim() + "...";
}
