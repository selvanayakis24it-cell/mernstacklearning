import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import CartItemRow from "../components/CartItemRow";
import "../styles/Cart.css";

function Cart() {
  const { cartItems, cartTotal, clearCart } = useCart();

  if (cartItems.length === 0) {
    return (
      <div className="cart-page cart-empty">
        <img src="/images/Cart_empty.png" alt="Empty cart" />
        <h2>Your cart is empty</h2>
        <p>Looks like you haven't added anything yet.</p>
        <Link to="/" className="browse-btn">
          Browse Restaurants
        </Link>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <h1>Your Cart</h1>

      <div className="cart-items-list">
        {cartItems.map((item) => (
          <CartItemRow key={item.cartKey} item={item} />
        ))}
      </div>

      <div className="cart-summary">
        <button className="clear-cart-btn" onClick={clearCart}>
          Clear Cart
        </button>
        <div className="cart-total">
          <span>Total</span>
          <span className="cart-total-amount">₹{cartTotal.toFixed(2)}</span>
        </div>
        <button className="checkout-btn">Proceed to Checkout</button>
      </div>
    </div>
  );
}

export default Cart;
