import "../styles/About.css";

function About() {
  return (
    <div className="about-page">
      <div className="about-card">
        <h1>About QuickBite</h1>
        <p>
          QuickBite is a food ordering web app built as a learning project to
          practice React, React Router, and the Context API. It uses real
          restaurant and menu data — restaurant listings with cuisines,
          ratings, and locations, plus a categorized menu with items you can
          add straight to your cart.
        </p>
        <p>
          Browse restaurants on the home page, search by name, area, or
          cuisine, open a restaurant to see its full menu, and build up an
          order in the cart with live quantity controls and a running total.
        </p>
        <h2>Built with</h2>
        <ul>
          <li>React (functional components + hooks)</li>
          <li>React Router DOM for navigation</li>
          <li>Context API for cart state</li>
          <li>Plain CSS, no UI framework</li>
          <li>Vite for the dev/build tooling</li>
        </ul>
      </div>
    </div>
  );
}

export default About;
