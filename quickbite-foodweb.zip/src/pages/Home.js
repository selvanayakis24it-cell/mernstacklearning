import { useMemo, useState } from "react";
import restaurantData from "../data/Restaurant.json";
import RestaurantCard from "../components/RestaurantCard";
import SearchBar from "../components/SearchBar";
import "../styles/Home.css";

function Home() {
  const [search, setSearch] = useState("");

  // Flatten the { info: {...} } wrapper from Restaurant.json so the rest
  // of the app can work with plain restaurant objects.
  const restaurants = useMemo(
    () => restaurantData.map((entry) => entry.info),
    []
  );

  // Filter restaurants live as the user types, matching against name,
  // area/locality, and cuisines.
  const filteredRestaurants = useMemo(() => {
    if (!search.trim()) return restaurants;
    const query = search.trim().toLowerCase();
    return restaurants.filter((r) => {
      const inName = r.name?.toLowerCase().includes(query);
      const inArea =
        r.areaName?.toLowerCase().includes(query) ||
        r.locality?.toLowerCase().includes(query);
      const inCuisines = r.cuisines?.some((c) =>
        c.toLowerCase().includes(query)
      );
      return inName || inArea || inCuisines;
    });
  }, [search, restaurants]);

  return (
    <div className="home-page">
      <section className="hero">
        <div className="hero-content">
          <h1>Craving something delicious?</h1>
          <p>Order food from the best restaurants near you</p>
          <SearchBar value={search} onChange={setSearch} />
        </div>
      </section>

      <section className="restaurant-list-section">
        <h2>
          {search ? `Results for "${search}"` : "Restaurants near you"}
          <span className="restaurant-count"> ({filteredRestaurants.length})</span>
        </h2>

        {filteredRestaurants.length === 0 ? (
          <div className="no-results">
            <p>No restaurants found matching "{search}".</p>
          </div>
        ) : (
          <div className="restaurant-grid">
            {filteredRestaurants.map((restaurant) => (
              <RestaurantCard key={restaurant.id} restaurant={restaurant} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default Home;
