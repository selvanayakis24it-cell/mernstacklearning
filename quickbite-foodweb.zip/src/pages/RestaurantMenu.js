import { useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import restaurantData from "../data/Restaurant.json";
import menuData from "../data/menu.json";
import MenuItemCard from "../components/MenuItemCard";
import { getRestaurantImage, formatCuisines } from "../utils/dataHelpers";
import "../styles/RestaurantMenu.css";

function RestaurantMenu() {
  const { id } = useParams();

  const restaurant = useMemo(() => {
    const entry = restaurantData.find((r) => r.info.id === id);
    return entry ? entry.info : null;
  }, [id]);

  // menu.json is a single shared menu (not one-file-per-restaurant in this
  // dataset), so every restaurant page renders the same set of categories.
  const categories = useMemo(
    () => menuData.map((entry) => entry.card.card),
    []
  );

  if (!restaurant) {
    return (
      <div className="restaurant-menu-page">
        <p className="not-found">
          Restaurant not found. <Link to="/">Go back home</Link>
        </p>
      </div>
    );
  }

  return (
    <div className="restaurant-menu-page">
      <div className="restaurant-menu-header">
        <img
          src={getRestaurantImage(restaurant.cloudinaryImageId)}
          alt={restaurant.name}
          className="restaurant-menu-banner"
          onError={(e) => {
            e.target.src = "/images/food.jpeg";
          }}
        />
        <div className="restaurant-menu-header-info">
          <h1>{restaurant.name}</h1>
          <p className="restaurant-menu-cuisines">
            {formatCuisines(restaurant.cuisines, 80)}
          </p>
          <div className="restaurant-menu-meta">
            {restaurant.avgRatingString && (
              <span className="meta-pill">★ {restaurant.avgRatingString}</span>
            )}
            {restaurant.costForTwo && (
              <span className="meta-pill">{restaurant.costForTwo}</span>
            )}
            <span className="meta-pill">
              {restaurant.areaName || restaurant.locality}
            </span>
          </div>
        </div>
      </div>

      <div className="menu-categories">
        {categories.map((category) => (
          <section className="menu-category" key={category.title}>
            <h2 className="menu-category-title">{category.title}</h2>
            <div className="menu-items-grid">
              {category.itemCards.map((itemCard, index) => (
                <MenuItemCard
                  key={`${category.title}-${itemCard.card.info.id}-${index}`}
                  item={itemCard.card.info}
                  categoryTitle={category.title}
                />
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

export default RestaurantMenu;
