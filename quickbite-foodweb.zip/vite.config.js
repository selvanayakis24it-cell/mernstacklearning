import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
//
// This project intentionally uses .js file extensions everywhere instead of
// .jsx, even though the files contain JSX syntax (<Component /> tags).
// Vite's React plugin only auto-transforms .jsx/.tsx files by default, so
// the options below tell esbuild (which both the dev server and the
// production build use on this Vite version) to also treat .js files
// under src/ as JSX.
export default defineConfig({
  plugins: [react()],
  esbuild: {
    loader: 'jsx',
    include: /src\/.*\.js$/,
    exclude: [],
  },
  optimizeDeps: {
    esbuildOptions: {
      loader: { '.js': 'jsx' },
    },
  },
})
