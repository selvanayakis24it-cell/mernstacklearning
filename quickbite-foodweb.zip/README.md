# QuickBite — Food Ordering App

A food ordering web app built with React + Vite, using real restaurant and
menu data (`Restaurant.json` / `menu.json`) and your own image assets.

**Note on file extensions:** every file in this project uses `.js`, not
`.jsx` — including files that contain JSX markup (`<Component />` tags).
That's not standard for React projects, but it's intentional here. See
"Why `.js` instead of `.jsx`?" below before renaming anything.

## Setup

```bash
npm install
npm run dev
```

Then open the local URL it prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview   # serve the built dist/ folder locally to test it
```

## Why `.js` instead of `.jsx`?

Vite's React plugin only auto-detects JSX syntax in files ending `.jsx` or
`.tsx` by default. To use `.js` everywhere while still writing JSX, this
project configures `vite.config.js` to tell esbuild to treat every `.js`
file under `src/` as JSX too:

```js
esbuild: {
  loader: 'jsx',
  include: /src\/.*\.js$/,
  exclude: [],
},
optimizeDeps: {
  esbuildOptions: {
    loader: { '.js': 'jsx' },
  },
},
```

This requires **Vite 5.x** and **`@vitejs/plugin-react` 4.x** specifically —
Vite's newer 8.x line switched its internal transform engine (Rolldown/Oxc)
in a way that doesn't yet support this `.js`+JSX combination for the dev
server, so don't upgrade those two packages without re-testing `npm run dev`
first.

If you ever want to switch back to the more standard `.jsx` extension, you
can revert `vite.config.js` to a plain `plugins: [react()]` and rename the
files — no other code changes needed.

## Project structure

```
src/
├── components/        Navbar.js, RestaurantCard.js, SearchBar.js, MenuItemCard.js, CartItemRow.js
├── pages/              Home.js, RestaurantMenu.js, Cart.js, About.js
├── context/            CartContext.js — cart state via React Context API
├── data/                Restaurant.json, menu.json
├── styles/              one CSS file per component/page, plus global.css for tokens
├── utils/              dataHelpers.js — image path fixing, price formatting, etc.
├── App.js
└── main.js
public/
└── images/             all restaurant + menu images (also empty-cart, icons)
```

## Data quirks this code handles

- `cloudinaryImageId` in `Restaurant.json` has no file extension — the code
  appends `.avif` to match the actual files in `public/images/`.
- Some menu items in `menu.json` are missing `rating`, `imgName`, `isVeg`,
  or `inStock` — the UI hides those bits gracefully instead of breaking.
- `defaultPrice` is stored in paise (e.g. `12500` = ₹125) — converted to
  rupees wherever it's displayed or added to the cart.
- A few menu item `id`s repeat across categories — list rendering uses a
  composite key (category + name + id + index) instead of the raw id.
- `menu.json` is one shared menu, not one file per restaurant, so every
  restaurant's menu page currently renders the same categories. Swap in
  per-restaurant menu data later if you get it.

## Routes

- `/` — home page with search + restaurant grid
- `/restaurant/:id` — a restaurant's menu
- `/cart` — cart with quantity controls and total
- `/about` — about page
